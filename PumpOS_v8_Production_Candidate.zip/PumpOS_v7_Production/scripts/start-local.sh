#!/usr/bin/env bash
set -euo pipefail
[ -f .env ] || cp .env.example .env
docker compose up -d postgres
npx prisma migrate deploy
npm run db:seed
npm run dev

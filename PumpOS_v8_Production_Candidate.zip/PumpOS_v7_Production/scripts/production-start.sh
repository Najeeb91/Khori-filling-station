#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL is required}"
: "${AUTH_SECRET:?AUTH_SECRET is required and must be at least 32 characters}"
npx prisma migrate deploy
npm run db:seed
npm run build
npm run start

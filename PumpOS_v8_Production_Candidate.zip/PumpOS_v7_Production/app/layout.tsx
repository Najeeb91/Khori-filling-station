import "./globals.css"; import type { Metadata } from "next";
export const metadata:Metadata={title:"PumpOS — Asian Filling Station",description:"Production petrol station operations system"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}

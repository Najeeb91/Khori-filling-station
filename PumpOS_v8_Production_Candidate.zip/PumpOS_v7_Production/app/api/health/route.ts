import { prisma } from "@/src/lib/prisma"; import { NextResponse } from "next/server";
export async function GET(){const started=Date.now();try{await prisma.$queryRaw`SELECT 1`;return NextResponse.json({ok:true,status:"healthy",database:"connected",latencyMs:Date.now()-started,version:"7.0.0"});}catch{return NextResponse.json({ok:false,status:"degraded",database:"unavailable"},{status:503});}}

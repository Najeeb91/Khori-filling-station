import { NextRequest } from "next/server";
import { prisma } from "@/src/lib/prisma";
import { verifyPassword,createSession } from "@/src/lib/auth";
import { audit } from "@/src/lib/audit";
import { fail,ok } from "@/src/lib/http";
import { z } from "zod";
const schema=z.object({email:z.string().email(),password:z.string().min(1)});
export async function POST(req:NextRequest){try{const p=schema.safeParse(await req.json());if(!p.success)return fail("Invalid login",422);const u=await prisma.user.findUnique({where:{email:p.data.email.toLowerCase()}});if(!u||!u.active||!(await verifyPassword(p.data.password,u.passwordHash)))return fail("Invalid email or password",401);await createSession(u.id);await audit({userId:u.id,action:"LOGIN",entity:"User",entityId:u.id,ip:req.headers.get("x-forwarded-for")??undefined,userAgent:req.headers.get("user-agent")??undefined});return ok({id:u.id,name:u.name,role:u.role});}catch(e:any){return fail(e?.message==="AUTH_SECRET_NOT_CONFIGURED"?"AUTH_SECRET is not configured":"Login failed",500)}}

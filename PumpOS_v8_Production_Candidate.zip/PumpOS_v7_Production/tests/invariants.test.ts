import {describe,it,expect} from 'vitest'; import {SETTINGS} from '../src/lib/settings'; import {allowed} from '../src/lib/permissions';
describe('PumpOS production invariants',()=>{
 it('has separate settings for every core module',()=>{for(const m of ['general','customers','fuel','tanks','pumps','daily','sales','purchases','expenses','security'])expect(Object.keys(SETTINGS[m]).length).toBeGreaterThan(0)});
 it('protects configuration from operators',()=>{expect(allowed('OPERATOR','configure')).toBe(false);expect(allowed('MANAGER','configure')).toBe(true);expect(allowed('ADMIN','admin')).toBe(true)});
});

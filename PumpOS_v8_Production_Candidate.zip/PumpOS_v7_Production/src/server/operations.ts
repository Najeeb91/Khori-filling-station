import { Prisma, PaymentMethod, StockMovementType } from "@prisma/client";
import { prisma } from "@/src/lib/prisma";
import { businessDate } from "@/src/lib/date";

const dec = (n: number | Prisma.Decimal) => new Prisma.Decimal(n);
const EPS = new Prisma.Decimal("0.001");

async function assertOpenDay(tx: Prisma.TransactionClient, date: Date) {
  const day = await tx.dailyUpdate.findUnique({ where: { businessDate: date } });
  if (!day) throw new Error("BUSINESS_DAY_NOT_OPEN");
  if (day.locked) throw new Error("BUSINESS_DAY_LOCKED");
  return day;
}

async function getSettingTx(tx: Prisma.TransactionClient, module: string, key: string, fallback: string) {
  const r = await tx.moduleSetting.findUnique({ where: { module_key: { module, key } } });
  return r?.value ?? fallback;
}

async function nextInvoiceNo(tx: Prisma.TransactionClient, prefix: string) {
  const key = `invoice:${prefix}`;
  const sequence = await tx.documentSequence.upsert({
    where: { key },
    update: { nextNumber: { increment: 1 } },
    create: { key, nextNumber: 2 },
  });
  const number = sequence.nextNumber - 1;
  return `${prefix}-${String(number).padStart(8, "0")}`;
}

async function customerBalance(tx: Prisma.TransactionClient, customerId: string) {
  const c = await tx.customer.findUnique({ where: { id: customerId } });
  if (!c) throw new Error("CUSTOMER_NOT_FOUND");
  const [debits, credits] = await Promise.all([
    tx.customerLedgerEntry.aggregate({ where: { customerId, type: "DEBIT" }, _sum: { amount: true } }),
    tx.customerLedgerEntry.aggregate({ where: { customerId, type: "CREDIT" }, _sum: { amount: true } }),
  ]);
  return dec(c.openingBal).add(debits._sum.amount ?? 0).sub(credits._sum.amount ?? 0);
}

export async function postSale(input: {
  businessDate: string; fuelProductId: string; quantity: number; paymentMethod: PaymentMethod;
  customerId?: string; nozzleId?: string; shiftId?: string; reference?: string;
}) {
  const date = businessDate(input.businessDate);
  return prisma.$transaction(async tx => {
    await assertOpenDay(tx, date);
    if (!Number.isFinite(input.quantity) || input.quantity <= 0) throw new Error("INVALID_QUANTITY");

    const fuel = await tx.fuelProduct.findUnique({ where: { id: input.fuelProductId } });
    if (!fuel || !fuel.active) throw new Error("FUEL_NOT_FOUND");

    let nozzle = null;
    if (input.nozzleId) {
      nozzle = await tx.nozzle.findUnique({ where: { id: input.nozzleId } });
      if (!nozzle || !nozzle.active) throw new Error("NOZZLE_NOT_FOUND");
      if (nozzle.fuelProductId !== fuel.id) throw new Error("NOZZLE_FUEL_MISMATCH");
    }

    if ((await getSettingTx(tx, "sales", "requireNozzleForFuelSale", "true")) === "true" && !nozzle) {
      throw new Error("NOZZLE_REQUIRED");
    }

    const maxQty = Number(await getSettingTx(tx, "sales", "maxQuantityPerSale", "10000"));
    if (!Number.isFinite(maxQty) || input.quantity > maxQty) throw new Error("SALE_QUANTITY_LIMIT");

    if (input.paymentMethod === PaymentMethod.CREDIT) {
      if (!input.customerId) throw new Error("CREDIT_CUSTOMER_REQUIRED");
      const customer = await tx.customer.findUnique({ where: { id: input.customerId } });
      if (!customer || !customer.active) throw new Error("CUSTOMER_NOT_FOUND");
    } else if (input.customerId) {
      // Customer may be selected for reference, but a non-credit sale must not alter receivables.
      const customer = await tx.customer.findUnique({ where: { id: input.customerId } });
      if (!customer || !customer.active) throw new Error("CUSTOMER_NOT_FOUND");
    }

    if (input.shiftId) {
      const shift = await tx.shift.findUnique({ where: { id: input.shiftId } });
      if (!shift) throw new Error("SHIFT_NOT_FOUND");
      if (shift.endAt) throw new Error("SHIFT_CLOSED");
      if (businessDate(shift.startAt.toISOString()).getTime() !== date.getTime()) throw new Error("SHIFT_DATE_MISMATCH");
    }

    const amount = dec(input.quantity).mul(fuel.saleRate);
    if (input.paymentMethod === PaymentMethod.CREDIT && input.customerId) {
      const balance = await customerBalance(tx, input.customerId);
      const customer = await tx.customer.findUnique({ where: { id: input.customerId } });
      if (customer && dec(customer.creditLimit).gt(0) && balance.add(amount).gt(customer.creditLimit)) {
        throw new Error("CREDIT_LIMIT_EXCEEDED");
      }
    }

    const stock = nozzle
      ? await tx.tank.findUnique({ where: { id: nozzle.tankId } })
      : await tx.tank.findFirst({ where: { fuelProductId: fuel.id, active: true }, orderBy: { currentQty: "desc" } });
    if (!stock || !stock.active) throw new Error("NO_TANK_FOR_FUEL");
    if (stock.fuelProductId !== fuel.id) throw new Error("TANK_FUEL_MISMATCH");
    if (stock.currentQty.lt(input.quantity)) throw new Error("INSUFFICIENT_STOCK");

    const updatedTank = await tx.tank.update({
      where: { id: stock.id },
      data: { currentQty: { decrement: input.quantity } },
    });
    const prefix = await getSettingTx(tx, "sales", "invoicePrefix", "AFS");
    const invoice = await nextInvoiceNo(tx, prefix);
    const sale = await tx.fuelSale.create({
      data: {
        invoiceNo: invoice, businessDate: date, quantity: input.quantity, rate: fuel.saleRate,
        amount, paymentMethod: input.paymentMethod, customerId: input.customerId,
        fuelProductId: fuel.id, nozzleId: input.nozzleId, shiftId: input.shiftId,
      },
    });
    await tx.payment.create({ data: { saleId: sale.id, method: input.paymentMethod, amount, reference: input.reference } });
    await tx.stockMovement.create({
      data: { businessDate: date, type: StockMovementType.SALE, quantity: dec(-input.quantity), referenceType: "FuelSale", referenceId: sale.id,
        fuelProductId: fuel.id, tankId: stock.id, saleId: sale.id, balanceAfter: updatedTank.currentQty },
    });
    if (input.paymentMethod === PaymentMethod.CREDIT) {
      await tx.customerLedgerEntry.create({ data: { customerId: input.customerId!, businessDate: date, type: "DEBIT", amount,
        paymentMethod: PaymentMethod.CREDIT, description: "Fuel credit sale", reference: invoice } });
    }
    return sale;
  });
}

export async function postPurchase(input: { businessDate: string; invoiceNo: string; supplierId: string; tankId: string; fuelProductId: string; quantity: number; rate: number }) {
  const date = businessDate(input.businessDate);
  return prisma.$transaction(async tx => {
    await assertOpenDay(tx, date);
    if (!Number.isFinite(input.quantity) || input.quantity <= 0 || !Number.isFinite(input.rate) || input.rate < 0) throw new Error("INVALID_PURCHASE");
    const [supplier, tank, fuel] = await Promise.all([
      tx.supplier.findUnique({ where: { id: input.supplierId } }),
      tx.tank.findUnique({ where: { id: input.tankId } }),
      tx.fuelProduct.findUnique({ where: { id: input.fuelProductId } }),
    ]);
    if (!supplier || !supplier.active) throw new Error("SUPPLIER_NOT_FOUND");
    if (!tank || !tank.active) throw new Error("TANK_NOT_FOUND");
    if (!fuel || !fuel.active) throw new Error("FUEL_NOT_FOUND");
    if (tank.fuelProductId !== fuel.id) throw new Error("TANK_FUEL_MISMATCH");
    if (tank.currentQty.add(input.quantity).gt(tank.capacity)) throw new Error("TANK_OVER_CAPACITY");
    const amount = dec(input.quantity).mul(input.rate);
    const purchase = await tx.purchase.create({ data: { invoiceNo: input.invoiceNo.trim(), businessDate: date, supplierId: supplier.id, totalAmount: amount,
      items: { create: { fuelProductId: fuel.id, tankId: tank.id, quantity: input.quantity, rate: input.rate, amount } } } });
    const updatedTank = await tx.tank.update({ where: { id: tank.id }, data: { currentQty: { increment: input.quantity } } });
    await tx.stockMovement.create({ data: { businessDate: date, type: StockMovementType.PURCHASE, quantity: input.quantity, referenceType: "Purchase", referenceId: purchase.id,
      fuelProductId: fuel.id, tankId: tank.id, balanceAfter: updatedTank.currentQty } });
    await tx.supplierLedgerEntry.create({ data: { supplierId: supplier.id, businessDate: date, type: "CREDIT", amount,
      paymentMethod: PaymentMethod.CREDIT, description: "Fuel purchase", reference: purchase.invoiceNo } });
    return purchase;
  });
}

export async function postExpense(input: { businessDate: string; category: string; description?: string; amount: number; paymentMethod: PaymentMethod }) {
  const date = businessDate(input.businessDate);
  return prisma.$transaction(async tx => {
    await assertOpenDay(tx, date);
    if (!Number.isFinite(input.amount) || input.amount <= 0) throw new Error("INVALID_AMOUNT");
    return tx.expense.create({ data: { businessDate: date, expenseDate: new Date(), category: input.category.trim(), description: input.description, amount: input.amount, paymentMethod: input.paymentMethod } });
  });
}

export async function recordMeter(input: { businessDate: string; nozzleId: string; closingMeter: number }) {
  const date = businessDate(input.businessDate);
  return prisma.$transaction(async tx => {
    await assertOpenDay(tx, date);
    if (!Number.isFinite(input.closingMeter) || input.closingMeter < 0) throw new Error("INVALID_METER");
    const n = await tx.nozzle.findUnique({ where: { id: input.nozzleId } });
    if (!n || !n.active) throw new Error("NOZZLE_NOT_FOUND");
    const existing = await tx.meterReading.findUnique({ where: { businessDate_nozzleId: { businessDate: date, nozzleId: n.id } } });
    const opening = existing?.openingMeter ?? n.currentMeter;
    if (dec(input.closingMeter).lt(opening) || dec(input.closingMeter).lt(n.currentMeter)) throw new Error("METER_CANNOT_DECREASE");
    const qty = dec(input.closingMeter).minus(opening);
    return tx.meterReading.upsert({
      where: { businessDate_nozzleId: { businessDate: date, nozzleId: n.id } },
      update: { closingMeter: input.closingMeter, quantity: qty },
      create: { businessDate: date, nozzleId: n.id, openingMeter: opening, closingMeter: input.closingMeter, quantity: qty },
    }).then(async r => { await tx.nozzle.update({ where: { id: n.id }, data: { currentMeter: input.closingMeter } }); return r; });
  });
}

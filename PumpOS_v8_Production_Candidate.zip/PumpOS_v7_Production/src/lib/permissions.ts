import { Role } from "@prisma/client";
const matrix:Record<string,Role[]>={
 read:["ADMIN","MANAGER","OPERATOR","ACCOUNTANT","VIEWER"],
 write:["ADMIN","MANAGER","OPERATOR","ACCOUNTANT"],
 configure:["ADMIN","MANAGER"],
 financial:["ADMIN","MANAGER","ACCOUNTANT"],
 closeDay:["ADMIN","MANAGER","ACCOUNTANT"],
 admin:["ADMIN"]
};
export function allowed(role:Role,action:keyof typeof matrix){return matrix[action].includes(role);}

export function businessDate(input?:string|Date){
 const d=input?new Date(input):new Date(); if(Number.isNaN(d.getTime()))throw new Error("INVALID_DATE");
 return new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate()));
}
export function today(){return businessDate();}

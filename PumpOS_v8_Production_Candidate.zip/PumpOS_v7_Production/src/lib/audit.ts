import { AuditAction, Prisma } from "@prisma/client";
import { prisma } from "./prisma";
export async function audit(input:{userId?:string;action:AuditAction;entity:string;entityId?:string;before?:unknown;after?:unknown;ip?:string;userAgent?:string}){
 return prisma.auditLog.create({data:{userId:input.userId,action:input.action,entity:input.entity,entityId:input.entityId,before:input.before as Prisma.InputJsonValue|undefined,after:input.after as Prisma.InputJsonValue|undefined,ip:input.ip,userAgent:input.userAgent}});
}

export const SETTINGS:Record<string,Record<string,string>>={
 general:{businessName:"Asian Filling Station",currency:"INR",timezone:"Asia/Kolkata",decimalPlaces:"2"},
 customers:{defaultCreditLimit:"0",creditApprovalRequired:"true",allowNegativeCredit:"false"},
 fuel:{defaultUnit:"L",priceChangeRequiresManager:"true",allowManualRateOverride:"false"},
 tanks:{lowStockThreshold:"1000",allowNegativeStock:"false",varianceToleranceLitres:"10"},
 pumps:{meterDecimalPlaces:"3",requireClosingMeter:"true"},
 daily:{requireOpening:"true",requireTankReadingsOnClose:"true",requireClosingCash:"true",cashVarianceTolerance:"0.01",autoCarryForwardStock:"true"},
 sales:{invoicePrefix:"AFS",allowCreditSales:"true",requireCustomerForCredit:"true",requireNozzleForFuelSale:"true",maxQuantityPerSale:"10000"},
 purchases:{requireSupplierInvoice:"true",updateTankStock:"true"},
 expenses:{cashExpenseRequiresApproval:"false",maxCashExpense:"50000"},
 security:{sessionHours:"12",auditRetentionDays:"3650",allowOperatorDelete:"false"}
};

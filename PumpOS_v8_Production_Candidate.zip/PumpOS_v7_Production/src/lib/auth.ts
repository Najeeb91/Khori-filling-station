import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import bcrypt from "bcryptjs";
import { prisma } from "./prisma";
import { Role } from "@prisma/client";
function secret(){ const v=process.env.AUTH_SECRET; if(!v || v.length<32) throw new Error("AUTH_SECRET_NOT_CONFIGURED"); return new TextEncoder().encode(v); }
export async function createSession(userId:string){
  const token=await new SignJWT({userId}).setProtectedHeader({alg:"HS256"}).setIssuedAt().setExpirationTime("12h").sign(secret());
  (await cookies()).set("pumpos_session",token,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",path:"/",maxAge:43200});
}
export async function clearSession(){(await cookies()).delete("pumpos_session");}
export async function getCurrentUser(){
 const token=(await cookies()).get("pumpos_session")?.value; if(!token)return null;
 try{const {payload}=await jwtVerify(token,secret()); const id=typeof payload.userId==="string"?payload.userId:null; if(!id)return null; return prisma.user.findUnique({where:{id},select:{id:true,name:true,email:true,role:true,active:true}});}catch{return null;}
}
export async function requireUser(){const u=await getCurrentUser();if(!u||!u.active)throw new Error("UNAUTHORIZED");return u;}
export async function requireRole(...roles:Role[]){const u=await requireUser();if(!roles.includes(u.role))throw new Error("FORBIDDEN");return u;}
export async function verifyPassword(password:string,hash:string){return bcrypt.compare(password,hash);}

import { z } from "zod";
const schema = z.object({ DATABASE_URL:z.string().min(1), AUTH_SECRET:z.string().min(32), APP_URL:z.string().url().optional() });
export function env(){ return schema.parse({DATABASE_URL:process.env.DATABASE_URL,AUTH_SECRET:process.env.AUTH_SECRET,APP_URL:process.env.APP_URL}); }

import { NextResponse } from "next/server";
export function ok<T>(data:T,status=200){return NextResponse.json({ok:true,data},{status});}
export function fail(error:string,status=400){return NextResponse.json({ok:false,error},{status});}
export function isAuthError(e:unknown){return e instanceof Error && (e.message==="UNAUTHORIZED"||e.message==="FORBIDDEN");}

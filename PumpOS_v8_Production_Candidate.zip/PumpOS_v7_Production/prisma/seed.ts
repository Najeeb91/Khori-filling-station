import {PrismaClient,Role} from '@prisma/client'; import bcrypt from 'bcryptjs'; import {SETTINGS} from '../src/lib/settings';
const prisma=new PrismaClient();
async function main(){
 const hash=await bcrypt.hash(process.env.SEED_ADMIN_PASSWORD||'ChangeMe123!',12);const admin=await prisma.user.upsert({where:{email:'admin@pumpos.local'},update:{},create:{name:'PumpOS Administrator',email:'admin@pumpos.local',passwordHash:hash,role:Role.ADMIN}});
 const petrol=await prisma.fuelProduct.upsert({where:{code:'MS'},update:{},create:{code:'MS',name:'Petrol',saleRate:94.77,purchaseRate:88}});
 const diesel=await prisma.fuelProduct.upsert({where:{code:'HSD'},update:{},create:{code:'HSD',name:'Diesel',saleRate:87.67,purchaseRate:81}});
 await prisma.customer.upsert({where:{code:'CASH'},update:{},create:{code:'CASH',name:'Cash Customer'}});
 const t1=await prisma.tank.upsert({where:{name:'Tank 1 - Petrol'},update:{},create:{name:'Tank 1 - Petrol',capacity:20000,currentQty:8000,fuelProductId:petrol.id}});
 const t2=await prisma.tank.upsert({where:{name:'Tank 2 - Diesel'},update:{},create:{name:'Tank 2 - Diesel',capacity:20000,currentQty:9000,fuelProductId:diesel.id}});
 const pump=await prisma.pump.upsert({where:{name:'Pump 1'},update:{serialNo:'P-001'},create:{name:'Pump 1',serialNo:'P-001'}});
 await prisma.nozzle.upsert({where:{name:'N1 Petrol'},update:{},create:{name:'N1 Petrol',pumpId:pump.id,fuelProductId:petrol.id,tankId:t1.id}});
 await prisma.nozzle.upsert({where:{name:'N2 Diesel'},update:{},create:{name:'N2 Diesel',pumpId:pump.id,fuelProductId:diesel.id,tankId:t2.id}});
 for(const [module,values] of Object.entries(SETTINGS))for(const [key,value] of Object.entries(values))await prisma.moduleSetting.upsert({where:{module_key:{module,key}},update:{},create:{module,key,value}});
 const d=new Date();const date=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate()));await prisma.dailyUpdate.upsert({where:{businessDate:date},update:{},create:{businessDate:date,openingCash:0}});
 const existing=await prisma.stockMovement.count({where:{businessDate:date,referenceType:'SEED'}}); if(existing===0) await prisma.stockMovement.createMany({data:[{businessDate:date,type:'OPENING',quantity:8000,referenceType:'SEED',fuelProductId:petrol.id,tankId:t1.id,balanceAfter:8000},{businessDate:date,type:'OPENING',quantity:9000,referenceType:'SEED',fuelProductId:diesel.id,tankId:t2.id,balanceAfter:9000}]});
 console.log(`PumpOS seeded. ${admin.email}`);
}
main().catch(e=>{console.error(e);process.exit(1)}).finally(()=>prisma.$disconnect());

# PumpOS Production Candidate v8

## Included hardening
- Transactional fuel sales, purchases, expenses and meter readings.
- Atomic invoice sequencing (no timestamp/random invoice collisions).
- Credit customer validation and credit-limit enforcement.
- Tank capacity enforcement on fuel receipts.
- Shift existence, open-state and business-date validation for sales.
- Business-day lock enforcement at the operation layer.
- Meter monotonicity and daily meter-vs-sales reconciliation.
- Tank stock movement ledger with balance-after snapshots.
- Role-based route protection and audit logging.

## Before go-live
1. Set a cryptographically random `AUTH_SECRET` of at least 32 characters.
2. Configure `DATABASE_URL` and `DIRECT_URL` for production PostgreSQL.
3. Run `npx prisma migrate deploy`.
4. Run `npx prisma generate`.
5. Create a production admin through a controlled seed/bootstrap process and rotate the initial password.
6. Enable HTTPS and production cookies.
7. Configure automated PostgreSQL backups and test a restore.
8. Run the application test suite and a real-world UAT using a copy of the database.
9. Verify every station's pump/nozzle/tank mapping before entering live sales.
10. Keep the existing manual/accounting process in parallel during the initial pilot.

## Operational rule
A locked business day must be immutable through normal application operations. Any correction should be performed through an authorized adjustment/reversal workflow with an audit trail rather than editing historical rows directly.

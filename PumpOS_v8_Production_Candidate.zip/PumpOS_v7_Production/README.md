# PumpOS v7 — Production Architecture

PumpOS is designed as a real petrol-station operations system for Asian Filling Station. It is **not** a static prototype. Core transactions are server-side, validated, audited and committed through PostgreSQL/Prisma transactions.

## Production contract

The source is intended to be deployable without changing application code. A deployment still necessarily needs infrastructure configuration: a PostgreSQL connection, a strong AUTH_SECRET, and the hosting domain/environment variables. Those are deployment secrets, not missing application features.

## Functional modules

- Authentication and role-based access
- Customers and credit ledger
- Fuel product/rate master
- Tanks and live stock
- Pumps and nozzles
- Meter readings
- Fuel sales with payment records
- Credit sales and customer ledger
- Purchases and supplier ledger
- Expenses
- Daily opening → live transactions → tank reconciliation → closing/locking
- Stock movement ledger and controlled adjustments
- Department-specific Master Settings with Save and Reset to Factory Defaults
- Reports/dashboard
- Audit trail
- Health endpoint

## Architecture

`Master Settings → Daily Update → Transaction → Stock/Ledger → Reconciliation → Reporting → Audit`

Critical writes use Prisma database transactions. Closed business dates are rejected by transactional operations. Stock cannot fall below zero or exceed tank capacity. Nozzle meters cannot decrease.

## Local production-like test

1. Copy `.env.example` to `.env` and set a strong `AUTH_SECRET`.
2. Run `docker compose up -d postgres`.
3. Run `npx prisma migrate deploy`.
4. Run `npm run db:seed`.
5. Run `npm run verify`.
6. Run `npm run dev`.

Seed login: `admin@pumpos.local` / `ChangeMe123!`. Change it before any real deployment.

## Deployment

The application source does not need code additions for deployment. The platform must provide PostgreSQL and environment variables. Run `npx prisma migrate deploy`, seed only if appropriate for the environment, then build and start Next.js.

Never use the seed password in a real station. Never commit `.env`.

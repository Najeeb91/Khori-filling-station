# Production readiness definition

Application code scope is designed to be complete for the included operational modules. Production deployment is still a separate infrastructure step.

Required before go-live:
- PostgreSQL production database
- Strong unique AUTH_SECRET
- HTTPS/domain
- Automated database backups and tested restore
- Least-privilege database credentials
- Monitoring/alerts
- Station-specific master data (tanks, pumps, nozzles, prices, users)
- Physical reconciliation with actual dispenser/tank readings
- User acceptance testing by station staff
- Payment gateway/device integration only if electronic payment is to be captured automatically
- Any OMC/ERP/fiscal integration required by the station

These are external integrations/configuration, not application buttons that should be added later.

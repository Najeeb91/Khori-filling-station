# Go-live checklist

1. Deploy PostgreSQL.
2. Set DATABASE_URL, DIRECT_URL and a 32+ character AUTH_SECRET.
3. Run `prisma migrate deploy`.
4. Run seed in a controlled environment or create the first admin manually.
5. Change the seed password immediately.
6. Configure station master data and module settings.
7. Open the first business day.
8. Enter physical tank quantities and dispenser meter readings.
9. Post one controlled test purchase and sale.
10. Verify stock, customer ledger, supplier ledger, cash and audit trail.
11. Test closing/locking and confirm further transactions are rejected.
12. Enable backups and monitoring.
13. Perform UAT with station operators.
